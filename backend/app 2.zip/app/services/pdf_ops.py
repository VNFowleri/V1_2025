import os, subprocess, shutil
from typing import List
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch

def generate_release_pdf(output_path: str, *, patient_name: str, dob: str, email: str, phone: str, signature_image_path: str, consent_text: str):
    c = canvas.Canvas(output_path, pagesize=LETTER)
    width, height = LETTER
    c.setFont("Helvetica-Bold", 16)
    c.drawString(1*inch, height - 1*inch, "Authorization to Release Medical Records")
    c.setFont("Helvetica", 11)
    text_obj = c.beginText(1*inch, height - 1.5*inch)
    text_obj.setLeading(14)
    for line in consent_text.split("\n"):
        text_obj.textLine(line)
    c.drawText(text_obj)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(1*inch, 2.5*inch, "Patient:")
    c.setFont("Helvetica", 11)
    c.drawString(2*inch, 2.5*inch, patient_name)
    c.drawString(1*inch, 2.2*inch, f"DOB: {dob}")
    c.drawString(3*inch, 2.2*inch, f"Email: {email or ''}")
    c.drawString(1*inch, 1.9*inch, f"Phone: {phone or ''}")
    c.showPage(); c.save(); return output_path

def ocr_to_searchable_pdf(in_path: str, out_path: str) -> str:
    exe = shutil.which("ocrmypdf")
    if not exe:
        import shutil as _sh
        _sh.copyfile(in_path, out_path); return out_path
    subprocess.run([exe, "--quiet", "--skip-text", in_path, out_path], check=True)
    return out_path

def merge_pdfs(pdf_paths: List[str], output_path: str):
    from PyPDF2 import PdfMerger
    merger = PdfMerger()
    for p in pdf_paths:
        if os.path.exists(p):
            merger.append(p)
    merger.write(output_path); merger.close(); return output_path

def write_cover_sheet(path: str, *, patient_name: str, dob: str, request_id: int):
    c = canvas.Canvas(path, pagesize=LETTER)
    width, height = LETTER
    c.setFont("Helvetica-Bold", 14)
    c.drawString(1*inch, height - 1*inch, "Medical Records Request (Patient Access)")
    c.setFont("Helvetica", 11)
    y = height - 1.5*inch
    lines = [
        f"Patient: {patient_name}",
        f"DOB: {dob}",
        f"Request ID: {request_id}",
        "Please fax the patient's full medical record to the number on the cover page.",
        "This request includes HIPAA-compliant authorization signed by the patient.",
    ]
    for line in lines:
        c.drawString(1*inch, y, line); y -= 0.3*inch
    c.showPage(); c.save(); return path
