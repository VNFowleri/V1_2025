# backend/app/routers/web.py

import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from sqlalchemy import select
from sqlalchemy.orm import joinedload
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.db import get_db
from app.models.patient import Patient
from app.models.consent import PatientConsent
from app.models.record_request import RecordRequest, ProviderRequest
from app.models.provider import Provider  # referenced by joinedload

# --- SINGLE declarations (do not repeat these anywhere else in this file) ---
router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
log = logging.getLogger(__name__)
# ----------------------------------------------------------------------------


# -------------------------
# Home
# -------------------------
@router.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    """Landing page."""
    return templates.TemplateResponse("index.html", {"request": request})


# -------------------------
# Registration
# -------------------------
@router.get("/register", response_class=HTMLResponse)
async def register_form(request: Request) -> HTMLResponse:
    return templates.TemplateResponse("register.html", {"request": request})


@router.post("/register")
async def register_submit(
    request: Request,
    db: AsyncSession = Depends(get_db),
    first_name: str = Form(""),
    last_name: str = Form(""),
    email: str = Form(""),
    phone: str = Form(""),
    dob: str = Form(""),
) -> RedirectResponse:
    """Create a Patient and redirect to consent."""
    # Only set columns that actually exist on the model to avoid mismatches.
    cols = set(Patient.__table__.columns.keys())
    payload: Dict[str, Any] = {}
    if "first_name" in cols:
        payload["first_name"] = first_name or None
    if "last_name" in cols:
        payload["last_name"] = last_name or None
    if "email" in cols:
        payload["email"] = email or None
    if "phone" in cols:
        payload["phone"] = phone or None
    if "dob" in cols:
        payload["dob"] = dob or None

    patient = Patient(**payload)
    db.add(patient)
    await db.commit()
    await db.refresh(patient)

    return RedirectResponse(url=f"/consent/{patient.id}", status_code=303)


# -------------------------
# Consent
# -------------------------
@router.get("/consent/{patient_id}", response_class=HTMLResponse)
async def consent_form(
    patient_id: int, request: Request, db: AsyncSession = Depends(get_db)
) -> HTMLResponse:
    res = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = res.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return templates.TemplateResponse(
        "consent.html",
        {"request": request, "patient": patient},
    )


@router.post("/consent/{patient_id}")
async def consent_submit(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
) -> RedirectResponse:
    """Persist consent (if required columns exist) and go to provider search."""
    cols = set(PatientConsent.__table__.columns.keys())
    payload: Dict[str, Any] = {"patient_id": patient_id}
    if "signed_at" in cols:
        payload["signed_at"] = datetime.utcnow()
    if "status" in cols:
        payload["status"] = "signed"
    consent = PatientConsent(**payload)
    db.add(consent)
    await db.commit()
    return RedirectResponse(url=f"/providers/{patient_id}", status_code=303)


# -------------------------
# Provider search
# -------------------------
@router.get("/providers/{patient_id}", response_class=HTMLResponse)
async def providers_page(
    patient_id: int, request: Request, db: AsyncSession = Depends(get_db)
) -> HTMLResponse:
    res = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = res.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return templates.TemplateResponse(
        "providers.html",
        {"request": request, "patient": patient},
    )


@router.post("/providers/{patient_id}")
async def providers_submit(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    zip_code: str = Form(""),
    radius: str = Form(""),
) -> RedirectResponse:
    """
    Create a RecordRequest and redirect to the status page.
    If your app creates ProviderRequest rows asynchronously, the status page
    will still render with an empty list until those rows are added.
    """
    cols = set(RecordRequest.__table__.columns.keys())
    payload: Dict[str, Any] = {"patient_id": patient_id}
    if "zip_code" in cols:
        payload["zip_code"] = zip_code or None
    if "radius" in cols:
        payload["radius"] = radius or None
    if "created_at" in cols:
        payload["created_at"] = datetime.utcnow()

    rr = RecordRequest(**payload)
    db.add(rr)
    await db.commit()
    await db.refresh(rr)

    return RedirectResponse(url=f"/status/{rr.id}", status_code=303)


# -------------------------
# Status page (fixed)
# -------------------------
@router.get("/status/{request_id}", response_class=HTMLResponse)
async def status_page(
    request_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> HTMLResponse:
    """
    Render the status page with all relationships preloaded via JOINs so the
    template never triggers async lazy loads (which would raise MissingGreenlet).
    Also parse any JSON status log safely.
    """
    # Eager-load everything the template might touch:
    #  - RecordRequest.patient
    #  - RecordRequest.provider_requests
    #  - ProviderRequest.provider
    q = (
        select(RecordRequest)
        .options(
            joinedload(RecordRequest.patient),
            joinedload(RecordRequest.provider_requests).joinedload(ProviderRequest.provider),
        )
        .where(RecordRequest.id == request_id)
    )
    result = await db.execute(q)
    rr = result.unique().scalar_one_or_none()
    if rr is None:
        raise HTTPException(status_code=404, detail="Record request not found")

    # Provider requests as a plain list (no further DB hits)
    prs: List[ProviderRequest] = list(rr.provider_requests or [])

    # Safe parse of status_log (can be NULL/empty/malformed)
    status_events: List[Dict[str, Any]] = []
    try:
        raw = getattr(rr, "status_log", None)
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode("utf-8", errors="ignore")
        if raw:
            parsed = json.loads(raw)
            status_events = parsed if isinstance(parsed, list) else [parsed]
    except Exception:
        log.exception("Failed to parse status_log for RecordRequest id=%s", rr.id)
        status_events = []

    return templates.TemplateResponse(
        "status.html",
        {
            "request": request,
            "rr": rr,          # fully-preloaded ORM object; rr.patient is safe
            "prs": prs,        # each pr.provider is preloaded
            "status_events": status_events,
        },
    )
