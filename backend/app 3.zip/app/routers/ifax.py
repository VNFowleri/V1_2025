from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime
import os, asyncio, logging
from pydantic import BaseModel, Field
from typing import Optional

from app.database.db import get_db, AsyncSessionLocal
from app.models import FaxFile, Patient, Provider, RecordRequest, ProviderRequest
from app.utils.ocr import extract_text_from_pdf, parse_name_and_dob
from app.services.ifax_service import download_fax

router = APIRouter()
logger = logging.getLogger(__name__)

class FaxWebhookPayload(BaseModel):
    jobId: int
    transactionId: int
    fromNumber: Optional[str] = None
    toNumber: Optional[str] = None
    faxCallStart: int
    faxReceivedPages: int = Field(..., alias="faxReceivedPages")
    faxStatus: str
    message: Optional[str] = None
    code: Optional[int] = None
    direction: Optional[str] = None
    class Config:
        extra = "allow"

@router.post("/receive")
async def receive_fax(request: Request, background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    try:
        payload_data = await request.json()
        payload = FaxWebhookPayload(**payload_data)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    fax = FaxFile(
        job_id=str(payload.jobId),
        transaction_id=str(payload.transactionId),
        sender=payload.fromNumber or "",
        receiver=payload.toNumber or "",
        received_time=datetime.utcfromtimestamp(payload.faxCallStart),
        file_path="",
        pdf_data=b"",
        ocr_text="",
    )
    db.add(fax); await db.commit(); await db.refresh(fax)

    background_tasks.add_task(process_fax, str(payload.jobId), fax.id, payload.transactionId, payload.direction)
    return {"status": "ok", "fax_id": fax.id}

async def process_fax(job_id: str, fax_record_id: int, transaction_id: int, direction: Optional[str] = None):
    try:
        async with AsyncSessionLocal() as db:
            dl = await asyncio.to_thread(download_fax, job_id, transaction_id)
            file_path = dl.get("file_path")
            if not file_path or not os.path.exists(file_path):
                raise Exception("Downloaded file not found")

            ocr_text = extract_text_from_pdf(file_path)

            with open(file_path, "rb") as f:
                pdf_content = f.read()

            fax = await db.get(FaxFile, fax_record_id)
            if fax:
                fax.file_path = os.path.abspath(file_path)
                fax.pdf_data = pdf_content
                fax.ocr_text = ocr_text
                db.add(fax); await db.commit(); await db.refresh(fax)

            first, last, dob = parse_name_and_dob(ocr_text or "")
            if first and last and dob:
                res = await db.execute(select(Patient).where(Patient.first_name.ilike(first), Patient.last_name.ilike(last), Patient.date_of_birth == dob))
                patient = res.scalars().first()
                if patient and fax:
                    fax.patient_id = patient.id
                    db.add(fax); await db.commit()

                    if fax.sender:
                        prq = await db.execute(select(ProviderRequest).where(ProviderRequest.record_request_id.in_([r.id for r in patient.record_requests])))
                        prs = prq.scalars().all()
                        for pr in prs:
                            prov = await db.get(Provider, pr.provider_id) if pr.provider_id else None
                            if prov and prov.fax and prov.fax.replace("+","").replace("-","")[-10:] == (fax.sender or "").replace("+","").replace("-","")[-10:]:
                                pr.status = "response_received"; pr.inbound_fax_id = fax.id
                                from datetime import datetime as dt
                                pr.responded_at = dt.utcnow()
                                db.add(pr); await db.commit()

                    await maybe_aggregate_and_finalize(patient.id, db)

    except Exception as e:
        logger.exception("Failed processing fax: %s", e)

async def maybe_aggregate_and_finalize(patient_id: int, db: AsyncSession):
    from sqlalchemy import select
    from app.services.pdf_ops import ocr_to_searchable_pdf, merge_pdfs
    import os, tempfile

    res = await db.execute(select(RecordRequest).where(RecordRequest.patient_id == patient_id))
    requests = res.scalars().all()
    for rr in requests:
        res2 = await db.execute(select(ProviderRequest).where(ProviderRequest.record_request_id == rr.id))
        prs = res2.scalars().all()
        if not prs:
            continue
        pending = [p for p in prs if p.fax_number_used and p.status not in ("response_received","fax_failed")]
        if pending:
            continue

        resfax = await db.execute(select(FaxFile).where(FaxFile.patient_id == patient_id))
        faxes = resfax.scalars().all()
        if not faxes:
            continue

        tmpdir = tempfile.mkdtemp()
        to_merge = []
        for fx in faxes:
            in_path = fx.file_path
            out_path = os.path.join(tmpdir, f"searchable_{fx.id}.pdf")
            try:
                ocr_to_searchable_pdf(in_path, out_path)
                to_merge.append(out_path)
            except Exception:
                to_merge.append(in_path)

        os.makedirs("storage", exist_ok=True)
        final_path = os.path.join("storage", f"patient_{patient_id}_request_{rr.id}_records.pdf")
        merge_pdfs(to_merge, final_path)

        rr.status = "complete"
        rr.compiled_pdf_path = os.path.abspath(final_path)
        from datetime import datetime as dt
        rr.completed_at = dt.utcnow()
        db.add(rr); await db.commit()

@router.post("/outbound-status")
async def outbound_status(payload: dict, db: AsyncSession = Depends(get_db)):
    job_id = str(payload.get("jobId") or "")
    status = payload.get("faxStatus") or payload.get("status") or ""
    from sqlalchemy import select
    res = await db.execute(select(ProviderRequest).where(ProviderRequest.outbound_job_id == job_id))
    pr = res.scalars().first()
    if pr:
        pr.status = "fax_delivered" if status.lower() in ("success","delivered","ok") else pr.status
        db.add(pr); await db.commit()
    return {"ok": True}