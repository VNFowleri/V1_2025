# backend/app/services/hospital_directory.py

import requests
import logging
from typing import List, Dict, Optional
import re

logger = logging.getLogger(__name__)

def search_hospitals(query: str, city: Optional[str] = None, state: Optional[str] = None) -> List[Dict]:
    """
    Search for hospitals using multiple sources.
    Returns list of hospitals with fax numbers.
    """
    results = []
    
    # 1. Try NPPES API first (most reliable)
    nppes_results = _search_nppes_hospitals(query, city, state)
    results.extend(nppes_results)
    
    # 2. If no results or few results, try web search
    if len(results) < 3:
        web_results = _search_hospitals_web(query, city, state)
        results.extend(web_results)
    
    # Remove duplicates based on name
    seen_names = set()
    unique_results = []
    for r in results:
        name_key = r.get("name", "").lower().strip()
        if name_key and name_key not in seen_names:
            seen_names.add(name_key)
            unique_results.append(r)
    
    return unique_results[:20]  # Return top 20

def _search_nppes_hospitals(query: str, city: Optional[str] = None, state: Optional[str] = None) -> List[Dict]:
    """Search NPPES for hospitals and healthcare organizations."""
    from app.services.provider_directory import search_providers
    
    results = []
    
    # Search by organization name
    try:
        providers = search_providers(
            organization_name=query,
            city=city,
            state=state,
            limit=10
        )
        
        for p in providers:
            # Filter for hospitals and healthcare facilities
            if p.get("type") == "NPI-2" or any(term in p.get("name", "").lower() 
                for term in ["hospital", "medical center", "health system", "clinic"]):
                results.append({
                    "name": p.get("name"),
                    "fax": p.get("fax"),
                    "phone": p.get("phone"),
                    "address": f"{p.get('address_line1', '')}, {p.get('city', '')}, {p.get('state', '')} {p.get('postal_code', '')}".strip(", "),
                    "city": p.get("city"),
                    "state": p.get("state"),
                    "npi": p.get("npi"),
                    "source": "NPPES",
                    "type": "hospital"
                })
    except Exception as e:
        logger.error(f"NPPES search error: {e}")
    
    return results

def _search_hospitals_web(query: str, city: Optional[str] = None, state: Optional[str] = None) -> List[Dict]:
    """
    Search for hospital information via web search.
    This is a placeholder - in production, you'd use Google Custom Search API
    or scrape hospital directories.
    """
    results = []
    
    # Build search query
    search_terms = [query]
    if city:
        search_terms.append(city)
    if state:
        search_terms.append(state)
    search_terms.extend(["hospital", "medical records fax"])
    
    search_query = " ".join(search_terms)
    
    # TODO: Implement actual web search
    # Option 1: Google Custom Search API
    # Option 2: Scrape hospital directories like:
    #   - Medicare.gov Hospital Compare
    #   - State health department websites
    #   - Healthcare.gov provider directory
    
    logger.info(f"Web search query: {search_query}")
    
    # Example of how to use Google Custom Search API:
    # api_key = os.getenv("GOOGLE_SEARCH_API_KEY")
    # cx = os.getenv("GOOGLE_SEARCH_CX")  # Custom Search Engine ID
    # if api_key and cx:
    #     url = "https://www.googleapis.com/customsearch/v1"
    #     params = {
    #         "key": api_key,
    #         "cx": cx,
    #         "q": search_query,
    #         "num": 5
    #     }
    #     response = requests.get(url, params=params)
    #     if response.ok:
    #         data = response.json()
    #         for item in data.get("items", []):
    #             # Extract fax from snippet/description
    #             fax = _extract_fax_from_text(item.get("snippet", ""))
    #             if fax:
    #                 results.append({
    #                     "name": item.get("title"),
    #                     "fax": fax,
    #                     "url": item.get("link"),
    #                     "source": "Web Search"
    #                 })
    
    return results

def _extract_fax_from_text(text: str) -> Optional[str]:
    """Extract fax number from text using regex."""
    # Common fax number patterns
    patterns = [
        r'fax[:\s]+(\+?1?[-.\s]?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4})',
        r'fax[:\s]+(\([0-9]{3}\)\s*[0-9]{3}-[0-9]{4})',
        r'f[:\s]+(\+?1?[-.\s]?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4})',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text.lower())
        if match:
            return _normalize_phone_number(match.group(1))
    
    return None

def _normalize_phone_number(phone: str) -> str:
    """Normalize phone number to standard format."""
    # Remove all non-digit characters
    digits = re.sub(r'\D', '', phone)
    
    # Format as +1-XXX-XXX-XXXX
    if len(digits) == 10:
        return f"+1-{digits[0:3]}-{digits[3:6]}-{digits[6:10]}"
    elif len(digits) == 11 and digits[0] == '1':
        return f"+1-{digits[1:4]}-{digits[4:7]}-{digits[7:11]}"
    
    return phone

def get_medicare_hospitals(city: Optional[str] = None, state: Optional[str] = None, zip_code: Optional[str] = None) -> List[Dict]:
    """
    Get hospitals from Medicare.gov Hospital Compare API.
    This is a real, free API that provides hospital information.
    """
    results = []
    
    try:
        # Medicare Hospital Compare API endpoint
        base_url = "https://data.medicare.gov/resource/xubh-q36u.json"
        
        params = {}
        if city:
            params["city"] = city.upper()
        if state:
            params["state"] = state.upper()
        if zip_code:
            params["zip_code"] = zip_code
        
        # Limit results
        params["$limit"] = 50
        
        response = requests.get(base_url, params=params, timeout=10)
        
        if response.ok:
            data = response.json()
            
            for hospital in data:
                # Extract hospital info
                name = hospital.get("hospital_name", "")
                phone = hospital.get("phone_number", "")
                
                results.append({
                    "name": name,
                    "phone": phone,
                    "fax": None,  # Medicare API doesn't provide fax
                    "address": hospital.get("address", ""),
                    "city": hospital.get("city", ""),
                    "state": hospital.get("state", ""),
                    "zip_code": hospital.get("zip_code", ""),
                    "hospital_type": hospital.get("hospital_type", ""),
                    "source": "Medicare.gov",
                    "type": "hospital",
                    "note": "Call to get medical records fax number"
                })
        
    except Exception as e:
        logger.error(f"Medicare API error: {e}")
    
    return results

def search_hospital_by_name(name: str) -> List[Dict]:
    """Search for a specific hospital by name."""
    results = []
    
    # Try NPPES
    nppes_results = _search_nppes_hospitals(name)
    results.extend(nppes_results)
    
    # Try Medicare
    medicare_results = get_medicare_hospitals()
    for h in medicare_results:
        if name.lower() in h.get("name", "").lower():
            results.append(h)
    
    return results[:10]

def validate_fax_number(fax: str) -> bool:
    """Validate that a fax number is properly formatted."""
    # Remove all non-digit characters
    digits = re.sub(r'\D', '', fax)
    
    # Should be 10 or 11 digits (with or without country code)
    return len(digits) in [10, 11]

def format_fax_number(fax: str) -> str:
    """Format a fax number consistently."""
    # Remove all non-digit characters
    digits = re.sub(r'\D', '', fax)
    
    # Format as +1-XXX-XXX-XXXX
    if len(digits) == 10:
        return f"+1-{digits[0:3]}-{digits[3:6]}-{digits[6:10]}"
    elif len(digits) == 11 and digits[0] == '1':
        return f"+1-{digits[1:4]}-{digits[4:7]}-{digits[7:11]}"
    
    return fax
