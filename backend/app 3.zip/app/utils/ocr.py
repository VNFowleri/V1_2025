import logging, os, re
from PIL import Image
import pytesseract
from pdf2image import convert_from_path

logger = logging.getLogger(__name__)

def extract_text_from_pdf(pdf_path: str) -> str:
    if not os.path.exists(pdf_path):
        logger.error(f"PDF file not found: {pdf_path}")
        return ""
    try:
        images = convert_from_path(pdf_path)
        all_text = []
        for page_num, img in enumerate(images, start=1):
            img = img.convert("L")
            img = img.point(lambda x: 0 if x < 140 else 255)
            text = pytesseract.image_to_string(img)
            all_text.append(text)
        return "\n".join(all_text)
    except Exception as e:
        logger.exception(f"Failed OCR on PDF: {pdf_path}. Error: {e}")
        return ""

def parse_name_and_dob(ocr_text: str):
    first_name = last_name = None
    dob_date = None
    from datetime import datetime

    patterns_name = [
        r"Patient\s*Name:\s*([A-Za-z,'-]+)\s+([A-Za-z,'-]+)",
        r"Name:\s*([A-Za-z,'-]+)\s+([A-Za-z,'-]+)",
        r"([A-Za-z,'-]+),\s*([A-Za-z,'-]+)\s*-\s*DOB",
    ]
    patterns_dob = [
        r"DOB[:\s]*([0-1]?\d/[0-3]?\d/\d{2,4})",
        r"Date\s*of\s*Birth[:\s]*([0-1]?\d/[0-3]?\d/\d{2,4})",
        r"DOB[:\s]*(\d{4}-\d{2}-\d{2})",
    ]
    for p in patterns_name:
        m = re.search(p, ocr_text, flags=re.IGNORECASE)
        if m:
            if "," in m.group(0):
                last_name = m.group(1).replace(",", "")
                first_name = m.group(2)
            else:
                first_name = m.group(1)
                last_name = m.group(2)
            break

    dob_str = None
    for p in patterns_dob:
        m = re.search(p, ocr_text, flags=re.IGNORECASE)
        if m:
            dob_str = m.group(1)
            break

    if dob_str:
        for fmt in ["%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d"]:
            try:
                dob_date = datetime.strptime(dob_str, fmt).date()
                break
            except Exception:
                continue
    return first_name, last_name, dob_date