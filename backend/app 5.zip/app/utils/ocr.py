# app/utils/ocr.py - v2.0
"""
Enhanced OCR Utilities for Medical Records Processing

Improvements:
- Better text preprocessing and cleaning
- Multiple pattern matching strategies
- Support for various date formats
- Better handling of OCR errors and noise
- Name parsing for multiple formats (First Last, Last, First, etc.)
- Support for middle names and initials
- Confidence scoring for parsed data
"""

import os
import re
import logging
from typing import Tuple, Optional, Dict
from datetime import datetime, date
import pytesseract
from pdf2image import convert_from_path

logger = logging.getLogger(__name__)


def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Extract text from PDF using OCR with enhanced preprocessing.

    Args:
        pdf_path: Path to the PDF file

    Returns:
        Extracted text as string
    """
    if not os.path.exists(pdf_path):
        logger.error(f"PDF file not found: {pdf_path}")
        return ""

    try:
        logger.info(f"Starting OCR on: {pdf_path}")

        # Convert PDF to images
        images = convert_from_path(pdf_path, dpi=300)  # Higher DPI for better OCR
        logger.info(f"Converted PDF to {len(images)} page(s)")

        all_text = []

        for page_num, img in enumerate(images, start=1):
            logger.debug(f"Processing page {page_num}/{len(images)}")

            # Convert to grayscale
            img = img.convert("L")

            # Enhance contrast (binarization)
            # Pixels below 140 become black, above become white
            img = img.point(lambda x: 0 if x < 140 else 255)

            # Run Tesseract OCR
            text = pytesseract.image_to_string(img, config='--psm 6')
            all_text.append(text)

            logger.debug(f"Page {page_num} extracted {len(text)} characters")

        full_text = "\n".join(all_text)
        logger.info(f"OCR complete: extracted {len(full_text)} total characters")

        return full_text

    except Exception as e:
        logger.exception(f"Failed OCR on PDF: {pdf_path}. Error: {e}")
        return ""


def parse_name_and_dob(ocr_text: str) -> Tuple[Optional[str], Optional[str], Optional[date]]:
    """
    Parse patient name and date of birth from OCR text using multiple strategies.

    Supports various formats:
    - Name: John Doe
    - Patient Name: John Michael Doe
    - Doe, John
    - DOB: 01/15/1980
    - Date of Birth: 1980-01-15
    - DOB: Jan 15, 1980

    Args:
        ocr_text: Text extracted from fax via OCR

    Returns:
        Tuple of (first_name, last_name, date_of_birth)
        Returns (None, None, None) if parsing fails
    """
    if not ocr_text:
        logger.warning("Empty OCR text provided")
        return None, None, None

    # Parse name
    name_result = _parse_name(ocr_text)
    first_name = name_result.get("first_name")
    last_name = name_result.get("last_name")

    # Parse DOB
    dob = _parse_dob(ocr_text)

    logger.info(
        f"Parsed: first_name={first_name}, last_name={last_name}, dob={dob}"
    )

    return first_name, last_name, dob


def _parse_name(text: str) -> Dict[str, Optional[str]]:
    """
    Parse patient name from text using multiple pattern matching strategies.

    Returns dict with first_name and last_name keys.
    """
    # Patterns for matching names (in order of preference)
    name_patterns = [
        # Pattern 1: "Patient Name: First Last" or "Name: First Last"
        (
            r'(?:Patient\s+)?Name\s*:\s*([A-Z][a-z]+(?:\s+[A-Z]\.?)?)\s+([A-Z][a-z]+)',
            False  # Not reversed
        ),

        # Pattern 2: "Patient: First Last"
        (
            r'Patient\s*:\s*([A-Z][a-z]+(?:\s+[A-Z]\.?)?)\s+([A-Z][a-z]+)',
            False
        ),

        # Pattern 3: "Last, First" format (common in medical records)
        (
            r'([A-Z][a-z]+),\s*([A-Z][a-z]+(?:\s+[A-Z]\.?)?)',
            True  # Reversed (last, first)
        ),

        # Pattern 4: "Name: Last, First"
        (
            r'Name\s*:\s*([A-Z][a-z]+),\s*([A-Z][a-z]+(?:\s+[A-Z]\.?)?)',
            True
        ),

        # Pattern 5: Near DOB (common formatting)
        (
            r'([A-Z][a-z]+),?\s+([A-Z][a-z]+)\s*[-–—]\s*DOB',
            False
        ),

        # Pattern 6: More flexible "Patient" keyword search
        (
            r'Patient\s*[:\-–—]?\s*([A-Z][a-z]+)\s+([A-Z][a-z]+)',
            False
        ),

        # Pattern 7: Very flexible - any capitalized name before DOB mention
        (
            r'([A-Z][a-z]+)\s+([A-Z][a-z]+)\s+(?:DOB|Date of Birth)',
            False
        )
    ]

    for pattern, is_reversed in name_patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)

        if match:
            if is_reversed:
                # Last name is first capture group
                last_name = match.group(1).strip()
                first_name = match.group(2).strip()
            else:
                # First name is first capture group
                first_name = match.group(1).strip()
                last_name = match.group(2).strip()

            # Remove middle initial if present
            first_name = re.sub(r'\s+[A-Z]\.?$', '', first_name)

            logger.debug(
                f"Name matched with pattern '{pattern[:50]}...': "
                f"{first_name} {last_name}"
            )

            return {
                "first_name": first_name,
                "last_name": last_name
            }

    logger.warning("Could not parse name from text")
    return {
        "first_name": None,
        "last_name": None
    }


def _parse_dob(text: str) -> Optional[date]:
    """
    Parse date of birth from text using multiple date format patterns.

    Supports:
    - MM/DD/YYYY
    - MM/DD/YY
    - YYYY-MM-DD
    - Month DD, YYYY (e.g., "Jan 15, 1980")
    - DD-MM-YYYY
    """
    # DOB patterns with their corresponding datetime formats
    dob_patterns = [
        # Pattern 1: DOB: MM/DD/YYYY or DOB: MM/DD/YY
        (r'DOB\s*:\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})', ["%m/%d/%Y", "%m/%d/%y", "%m-%d-%Y", "%m-%d-%y"]),

        # Pattern 2: Date of Birth: MM/DD/YYYY
        (r'Date\s+of\s+Birth\s*:\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})', ["%m/%d/%Y", "%m/%d/%y"]),

        # Pattern 3: DOB YYYY-MM-DD (ISO format)
        (r'DOB\s*:\s*(\d{4}-\d{2}-\d{2})', ["%Y-%m-%d"]),

        # Pattern 4: Month name formats (e.g., "Jan 15, 1980" or "January 15, 1980")
        (
            r'DOB\s*:\s*([A-Z][a-z]+\.?\s+\d{1,2},?\s+\d{4})',
            ["%B %d, %Y", "%b %d, %Y", "%B %d %Y", "%b %d %Y"]
        ),

        # Pattern 5: Just the date without "DOB:" prefix (fallback)
        (r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})', ["%m/%d/%Y", "%m/%d/%y"]),
    ]

    for pattern, formats in dob_patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)

        if match:
            dob_str = match.group(1).strip()

            # Try each format
            for fmt in formats:
                try:
                    parsed_date = datetime.strptime(dob_str, fmt).date()

                    # Validate date is reasonable (not in future, not too old)
                    today = date.today()
                    age = (today - parsed_date).days / 365.25

                    if 0 <= age <= 120:  # Reasonable age range
                        logger.debug(
                            f"DOB matched with pattern '{pattern[:50]}...' and format '{fmt}': "
                            f"{parsed_date} (age: {age:.1f})"
                        )
                        return parsed_date
                    else:
                        logger.debug(
                            f"Parsed date {parsed_date} results in age {age:.1f}, "
                            "which is outside reasonable range"
                        )

                except ValueError:
                    continue

    logger.warning("Could not parse DOB from text")
    return None


def extract_hospital_names(ocr_text: str) -> list[str]:
    """
    Extract potential hospital/provider names from OCR text.

    Useful for matching incoming faxes to provider requests.

    Args:
        ocr_text: Text extracted from fax

    Returns:
        List of potential hospital names found
    """
    hospital_keywords = [
        r'Hospital',
        r'Medical Center',
        r'Clinic',
        r'Health System',
        r'Healthcare',
        r'Regional Medical',
        r'University Hospital',
        r'Community Hospital',
        r'Memorial',
        r'General Hospital'
    ]

    hospitals = []

    # Look for hospital names (typically capitalized)
    for keyword in hospital_keywords:
        pattern = rf'([A-Z][A-Za-z\s]+{keyword}[A-Za-z\s]*)'
        matches = re.findall(pattern, ocr_text)
        hospitals.extend(matches)

    # Clean up and deduplicate
    hospitals = [h.strip() for h in hospitals]
    hospitals = list(set(hospitals))

    logger.debug(f"Found {len(hospitals)} potential hospital names: {hospitals}")

    return hospitals


def clean_ocr_text(text: str) -> str:
    """
    Clean OCR text by removing common OCR errors and noise.

    Args:
        text: Raw OCR text

    Returns:
        Cleaned text
    """
    if not text:
        return ""

    # Remove excessive whitespace
    text = re.sub(r'\s+', ' ', text)

    # Remove page numbers (common OCR artifact)
    text = re.sub(r'Page\s+\d+\s+of\s+\d+', '', text, flags=re.IGNORECASE)

    # Remove common OCR noise characters
    text = re.sub(r'[|▌►◄←→↑↓]', '', text)

    # Normalize line breaks
    text = re.sub(r'\n\s*\n', '\n\n', text)

    return text.strip()


# For testing and debugging
def parse_with_confidence(ocr_text: str) -> Dict:
    """
    Parse name and DOB with confidence scoring.

    Returns:
        Dict with parsed data and confidence scores
    """
    first_name, last_name, dob = parse_name_and_dob(ocr_text)

    # Calculate confidence based on what was successfully parsed
    confidence = 0.0

    if first_name and last_name:
        confidence += 0.5  # 50% for having name

        # Bonus if name looks clean (no numbers, reasonable length)
        if (re.match(r'^[A-Za-z\-\']+$', first_name) and
                re.match(r'^[A-Za-z\-\']+$', last_name) and
                2 <= len(first_name) <= 20 and 2 <= len(last_name) <= 20):
            confidence += 0.2

    if dob:
        confidence += 0.3  # 30% for having DOB

    return {
        "first_name": first_name,
        "last_name": last_name,
        "dob": dob,
        "confidence": confidence,
        "has_name": bool(first_name and last_name),
        "has_dob": bool(dob)
    }