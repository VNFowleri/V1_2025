# backend/app/routers/web.py - IMPROVED VERSION

import os
import json
import base64
import logging
from datetime import datetime
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Request, Form, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from sqlalchemy import select, or_
from sqlalchemy.orm import joinedload
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.db import get_db
from app.models.patient import Patient
from app.models.consent import PatientConsent
from app.models.record_request import RecordRequest, ProviderRequest
from app.models.provider import Provider
from app.services.pdf_ops import generate_release_pdf
from app.services.auth_service import generate_magic_link, verify_magic_link, send_magic_link_email
from app.services.hospital_directory import search_hospitals, get_medicare_hospitals, validate_fax_number, \
    format_fax_number

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
log = logging.getLogger(__name__)

CONSENT_TEXT = """I authorize the release of my complete medical record, including but not limited to physician notes,
diagnoses, medications, laboratory results, imaging, and billing records, to myself (patient access).
This authorization is voluntary and may be revoked in writing at any time except to the extent that action
has already been taken. This authorization will expire 180 days from the date of signature.
"""


# -------------------------
# Helper Functions
# -------------------------
def get_patient_from_session(patient_uuid: str, db: AsyncSession):
    """Get patient from session UUID."""
    # In production, use actual session management
    return patient_uuid


# -------------------------
# Home / Landing
# -------------------------
@router.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    """Landing page with login/signup options."""
    return templates.TemplateResponse("index.html", {"request": request})


# -------------------------
# Authentication
# -------------------------
@router.get("/login", response_class=HTMLResponse)
async def login_form(request: Request) -> HTMLResponse:
    """Login page."""
    return templates.TemplateResponse("login.html", {"request": request})


@router.post("/login")
async def login_submit(
        request: Request,
        email: str = Form(...),
        db: AsyncSession = Depends(get_db)
) -> HTMLResponse:
    """Send magic link to user's email."""
    # Check if patient exists
    result = await db.execute(select(Patient).where(Patient.email == email))
    patient = result.scalar_one_or_none()

    if not patient:
        return templates.TemplateResponse(
            "login.html",
            {
                "request": request,
                "error": "No account found with this email. Please sign up first."
            }
        )

    # Generate and send magic link
    base_url = os.getenv("BASE_EXTERNAL_URL", "http://localhost:8000")
    magic_link = generate_magic_link(email, base_url)
    send_magic_link_email(email, magic_link)

    return templates.TemplateResponse(
        "login_sent.html",
        {
            "request": request,
            "email": email,
            "magic_link": magic_link  # Remove in production
        }
    )


@router.get("/auth/verify")
async def verify_login(
        request: Request,
        token: str,
        db: AsyncSession = Depends(get_db)
) -> RedirectResponse:
    """Verify magic link and log user in."""
    email = verify_magic_link(token)

    if not email:
        raise HTTPException(status_code=400, detail="Invalid or expired login link")

    # Get patient
    result = await db.execute(select(Patient).where(Patient.email == email))
    patient = result.scalar_one_or_none()

    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Redirect to portal
    # In production, set a secure session cookie here
    response = RedirectResponse(url=f"/portal/{patient.uuid}", status_code=303)
    response.set_cookie(key="patient_uuid", value=str(patient.uuid), httponly=True, max_age=86400 * 30)

    return response


# -------------------------
# Registration
# -------------------------
@router.get("/register", response_class=HTMLResponse)
async def register_form(request: Request) -> HTMLResponse:
    return templates.TemplateResponse("register.html", {"request": request})


@router.post("/register")
async def register_submit(
        request: Request,
        db: AsyncSession = Depends(get_db),
        first_name: str = Form(""),
        last_name: str = Form(""),
        email: str = Form(""),
        phone: str = Form(""),
        dob: str = Form(""),
) -> RedirectResponse:
    """Create a Patient and redirect to consent."""
    # Check if email already exists
    if email:
        result = await db.execute(select(Patient).where(Patient.email == email))
        existing = result.scalar_one_or_none()
        if existing:
            return RedirectResponse(url=f"/login?error=email_exists", status_code=303)

    date_of_birth = None
    if dob:
        try:
            date_of_birth = datetime.strptime(dob, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format")

    patient = Patient(
        first_name=first_name or "",
        last_name=last_name or "",
        email=email or None,
        phone=phone or None,
        date_of_birth=date_of_birth
    )
    db.add(patient)
    await db.commit()
    await db.refresh(patient)

    return RedirectResponse(url=f"/consent/{patient.id}", status_code=303)


# -------------------------
# Consent
# -------------------------
@router.get("/consent/{patient_id}", response_class=HTMLResponse)
async def consent_form(
        patient_id: int, request: Request, db: AsyncSession = Depends(get_db)
) -> HTMLResponse:
    res = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = res.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return templates.TemplateResponse(
        "consent.html",
        {"request": request, "patient": patient, "CONSENT_TEXT": CONSENT_TEXT}
    )


@router.post("/consent/{patient_id}")
async def consent_submit(
        patient_id: int,
        request: Request,
        signature_data_url: str = Form(...),
        db: AsyncSession = Depends(get_db),
) -> RedirectResponse:
    """Process consent signature, generate PDF, and save consent record."""
    p = await db.get(Patient, patient_id)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")

    sig_dir = "storage/signatures"
    os.makedirs(sig_dir, exist_ok=True)

    try:
        b64 = signature_data_url.split(",")[-1]
        img_bytes = base64.b64decode(b64)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid signature data: {e}")

    sig_path = os.path.join(sig_dir, f"sig_{patient_id}.png")
    with open(sig_path, "wb") as f:
        f.write(img_bytes)

    rel_dir = "storage/releases"
    os.makedirs(rel_dir, exist_ok=True)
    release_pdf_path = os.path.join(rel_dir, f"release_patient_{patient_id}.pdf")

    patient_name = f"{p.first_name} {p.last_name}"
    dob_str = p.date_of_birth.isoformat() if p.date_of_birth else ""

    generate_release_pdf(
        release_pdf_path,
        patient_name=patient_name,
        dob=dob_str,
        email=p.email or "",
        phone=p.phone or "",
        signature_image_path=sig_path,
        consent_text=CONSENT_TEXT
    )

    consent = PatientConsent(
        patient_id=p.id,
        consent_pdf_path=release_pdf_path,
        signature_image_path=sig_path,
        release_text_version="v1",
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )
    db.add(consent)
    await db.commit()
    await db.refresh(consent)

    return RedirectResponse(url=f"/search-providers/{patient_id}", status_code=303)


# -------------------------
# Provider Search (NEW - Improved)
# -------------------------
@router.get("/search-providers/{patient_id}", response_class=HTMLResponse)
async def search_providers_page(
        patient_id: int, request: Request, db: AsyncSession = Depends(get_db)
) -> HTMLResponse:
    """New provider search page with hospital search."""
    res = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = res.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    return templates.TemplateResponse(
        "search_providers.html",
        {"request": request, "patient": patient}
    )


@router.post("/search-providers/{patient_id}")
async def search_providers_submit(
        patient_id: int,
        request: Request,
        db: AsyncSession = Depends(get_db),
        search_query: str = Form(""),
        city: str = Form(""),
        state: str = Form(""),
        zip_code: str = Form(""),
) -> HTMLResponse:
    """Search for hospitals and return results."""
    res = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = res.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Search hospitals using multiple sources
    hospitals = []

    if search_query:
        hospitals.extend(search_hospitals(search_query, city, state))

    if city or state or zip_code:
        medicare_hospitals = get_medicare_hospitals(city, state, zip_code)
        hospitals.extend(medicare_hospitals)

    # Remove duplicates
    seen = set()
    unique_hospitals = []
    for h in hospitals:
        key = h.get("name", "").lower().strip()
        if key and key not in seen:
            seen.add(key)
            unique_hospitals.append(h)

    return templates.TemplateResponse(
        "search_results.html",
        {
            "request": request,
            "patient": patient,
            "hospitals": unique_hospitals,
            "search_query": search_query,
            "city": city,
            "state": state
        }
    )


# -------------------------
# Review Providers (NEW)
# -------------------------
@router.get("/review-providers/{patient_id}", response_class=HTMLResponse)
async def review_providers_page(
        patient_id: int, request: Request, db: AsyncSession = Depends(get_db)
) -> HTMLResponse:
    """Page to review and edit selected providers before sending faxes."""
    res = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = res.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    return templates.TemplateResponse(
        "review_providers.html",
        {"request": request, "patient": patient}
    )


@router.post("/review-providers/{patient_id}")
async def review_providers_submit(
        patient_id: int,
        request: Request,
        db: AsyncSession = Depends(get_db),
        selected_providers: str = Form(""),  # JSON array of selected providers
) -> RedirectResponse:
    """Process selected providers and create requests."""
    from app.services.ifax_service import send_fax
    from app.services.pdf_ops import write_cover_sheet

    p = await db.get(Patient, patient_id)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Get consent
    res_c = await db.execute(select(PatientConsent).where(PatientConsent.patient_id == p.id))
    consent = res_c.scalars().first()
    if not consent:
        raise HTTPException(status_code=400, detail="Consent missing")

    # Parse selected providers
    try:
        providers_data = json.loads(selected_providers) if selected_providers else []
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid provider data: {e}")

    if not providers_data:
        raise HTTPException(status_code=400, detail="No providers selected")

    # Create providers in database
    providers = []
    for pdata in providers_data:
        name = pdata.get("name")
        fax = pdata.get("fax")

        if not name or not fax:
            continue

        # Validate and format fax
        if not validate_fax_number(fax):
            log.warning(f"Invalid fax number for {name}: {fax}")
            continue

        fax = format_fax_number(fax)

        # Create provider
        provider = Provider(
            name=name,
            fax=fax,
            npi=pdata.get("npi"),
            address_line1=pdata.get("address"),
            city=pdata.get("city"),
            state=pdata.get("state"),
            phone=pdata.get("phone"),
            source=pdata.get("source", "manual"),
            type="hospital"
        )
        db.add(provider)
        await db.flush()
        providers.append(provider)

    if not providers:
        raise HTTPException(status_code=400, detail="No valid providers to contact")

    # Create record request
    rr = RecordRequest(
        patient_id=p.id,
        requested_cities="",
        requested_zips="",
        requested_providers_json=selected_providers,
        release_pdf_path=consent.consent_pdf_path,
        status="in_progress",
    )
    db.add(rr)
    await db.commit()
    await db.refresh(rr)

    # Send faxes
    base_url = os.getenv("BASE_EXTERNAL_URL", "")
    callback = f"{base_url}/ifax/outbound-status" if base_url else None

    covers_dir = "storage/covers"
    os.makedirs(covers_dir, exist_ok=True)
    patient_name = f"{p.first_name} {p.last_name}"
    dob_str = p.date_of_birth.isoformat() if p.date_of_birth else ""

    for prov in providers:
        cover_path = os.path.join(covers_dir, f"cover_rr{rr.id}_prov{prov.id}.pdf")
        write_cover_sheet(
            cover_path,
            patient_name=patient_name,
            dob=dob_str,
            request_id=rr.id
        )

        try:
            res = send_fax(
                to_number=prov.fax,
                file_paths=[cover_path, consent.consent_pdf_path],
                cover_text=None,
                callback_url=callback
            )
            job_id = str(res.get("jobId") or res.get("data", {}).get("jobId") or "")
            pr = ProviderRequest(
                record_request_id=rr.id,
                provider_id=prov.id,
                fax_number_used=prov.fax,
                status="fax_sent",
                outbound_job_id=job_id,
                sent_at=datetime.utcnow()
            )
        except Exception as e:
            log.exception(f"Failed to send fax to {prov.name}: {e}")
            pr = ProviderRequest(
                record_request_id=rr.id,
                provider_id=prov.id,
                fax_number_used=prov.fax,
                status="fax_failed",
                failed_reason=str(e)
            )
        db.add(pr)

    await db.commit()

    return RedirectResponse(url=f"/status/{rr.id}", status_code=303)


# -------------------------
# Status page
# -------------------------
@router.get("/status/{request_id}", response_class=HTMLResponse)
async def status_page(
        request_id: int,
        request: Request,
        db: AsyncSession = Depends(get_db),
) -> HTMLResponse:
    """Render the status page with all relationships preloaded via JOINs."""
    q = (
        select(RecordRequest)
        .options(
            joinedload(RecordRequest.patient),
            joinedload(RecordRequest.provider_requests).joinedload(ProviderRequest.provider),
        )
        .where(RecordRequest.id == request_id)
    )
    result = await db.execute(q)
    rr = result.unique().scalar_one_or_none()
    if rr is None:
        raise HTTPException(status_code=404, detail="Record request not found")

    prs: List[ProviderRequest] = list(rr.provider_requests or [])

    return templates.TemplateResponse(
        "status.html",
        {"request": request, "rr": rr, "prs": prs}
    )