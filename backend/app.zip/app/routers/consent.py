import os, base64
from fastapi import APIRouter, Depends, HTTPException, Request, Form
from starlette.responses import RedirectResponse
from starlette.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.db import get_db
from app.models import Patient, PatientConsent
from app.services.pdf_ops import generate_release_pdf

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

CONSENT_TEXT = """I authorize the release of my complete medical record, including but not limited to physician notes,
diagnoses, medications, laboratory results, imaging, and billing records, to myself (patient access).
This authorization is voluntary and may be revoked in writing at any time except to the extent that action
has already been taken. This authorization will expire 180 days from the date of signature.
"""

@router.get("/{patient_id}")
async def consent_form(request: Request, patient_id: int, db: AsyncSession = Depends(get_db)):
    p = await db.get(Patient, patient_id)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")
    return templates.TemplateResponse("consent.html", {"request": request, "patient": p, "CONSENT_TEXT": CONSENT_TEXT})

@router.post("/{patient_id}")
async def submit_consent(request: Request,
                         patient_id: int,
                         signature_data_url: str = Form(...),
                         db: AsyncSession = Depends(get_db)):
    p = await db.get(Patient, patient_id)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")

    sig_dir = "storage/signatures"; os.makedirs(sig_dir, exist_ok=True)
    b64 = signature_data_url.split(",")[-1]
    img_bytes = base64.b64decode(b64)
    sig_path = os.path.join(sig_dir, f"sig_{patient_id}.png")
    with open(sig_path, "wb") as f:
        f.write(img_bytes)

    rel_dir = "storage/releases"; os.makedirs(rel_dir, exist_ok=True)
    release_pdf_path = os.path.join(rel_dir, f"release_patient_{patient_id}.pdf")
    patient_name = f"{p.first_name} {p.last_name}"
    dob_str = p.date_of_birth.isoformat() if p.date_of_birth else ""
    generate_release_pdf(release_pdf_path, patient_name=patient_name, dob=dob_str, email=p.email or "", phone=p.phone or "", signature_image_path=sig_path, consent_text=CONSENT_TEXT)

    pc = PatientConsent(patient_id=p.id, consent_pdf_path=release_pdf_path, signature_image_path=sig_path, release_text_version="v1", ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    db.add(pc); await db.commit(); await db.refresh(pc)

    return RedirectResponse(url=f"/providers/{p.id}", status_code=303)
