import requests, os, logging, base64
from typing import List, Optional, Dict

logger = logging.getLogger(__name__)
IFAX_ACCESS_TOKEN = os.getenv("IFAX_ACCESS_TOKEN")

BASE_HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "accessToken": IFAX_ACCESS_TOKEN or ""
}

def download_fax(job_id: str, transaction_id: int):
    url = "https://api.ifaxapp.com/v1/customer/inbound/fax-download"
    payload = {"jobId": str(job_id), "transactionId": str(transaction_id)}
    r = requests.post(url, json=payload, headers=BASE_HEADERS, timeout=60)
    if r.status_code != 200:
        return {"error": "Failed to download fax", "status": r.status_code, "body": r.text}
    data = r.json()
    if data.get("status") != 1:
        return {"error": "Fax download failed", "body": data}
    file_b64 = data.get("data")
    if not file_b64:
        return {"error": "No file data in response"}
    pdf_bytes = base64.b64decode(file_b64)
    out_dir = os.path.join(os.getcwd(), "received_faxes")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{job_id}.pdf")
    with open(out_path, "wb") as f:
        f.write(pdf_bytes)
    return {"message": "Fax downloaded", "file_path": out_path}

def send_fax(*, to_number: str, file_paths: List[str], cover_text: Optional[str]=None, callback_url: Optional[str]=None) -> Dict:
    url = "https://api.ifaxapp.com/v1/customer/fax-send"
    files_payload = []
    for p in file_paths:
        with open(p, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")
            files_payload.append({"name": os.path.basename(p), "data": b64})
    payload = {
        "recipient": {"faxNumber": to_number},
        "files": files_payload,
        "coverPage": {"text": cover_text or ""},
    }
    if callback_url:
        payload["webhook"] = {"statusUrl": callback_url}
    r = requests.post(url, json=payload, headers=BASE_HEADERS, timeout=60)
    if r.status_code != 200:
        logger.error("Fax send failed: %s %s", r.status_code, r.text)
        return {"error": "send_failed", "status": r.status_code, "body": r.text}
    try:
        data = r.json()
    except Exception:
        return {"error": "invalid_json", "body": r.text}
    return data